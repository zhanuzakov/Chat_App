//
//  ChatViewController.swift
//  Messenger
//
//  Created by Гость on 09.11.2021.
//

import UIKit
import Firebase

class ChatViewController: UIViewController {

    @IBOutlet weak var messagesTableView: UITableView!
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var inputViewHeightConstraint: NSLayoutConstraint!
    
    private var messages: [MessageModel] = [] {
        didSet {
            messagesTableView.reloadData()
        }
    }
    private let messagesDB = Database.database().reference().child("Messages")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        inputTextField.delegate = self
        inputTextField.tag = 1
        
        sendButton.layer.cornerRadius = 4
        sendButton.layer.masksToBounds = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tableViewWasTapped))
        messagesTableView.addGestureRecognizer(tapGesture)
        
        messagesTableView.delegate = self
        messagesTableView.dataSource = self
        messagesTableView.separatorStyle = .none
        messagesTableView.register(UINib(nibName: MessageCell.identifier, bundle: Bundle(for: MessageCell.self)), forCellReuseIdentifier: MessageCell.identifier)
        
        fetchMessages()
        
    }
    
    @IBAction func sendButtonPressed(_ sender: Any) {
        
        guard let message = inputTextField.text else { return }
        guard let email = Auth.auth().currentUser?.email else { return }
        
        let messageDict = ["sender": email, "message": message]
        
        sendButton.isEnabled = false
        
        messagesDB.childByAutoId().setValue(messageDict) { [weak self] error, reference in
            if error != nil {
                print("could not save to db, \(error!)")
            } else {
                self?.sendButton.isEnabled = true
                self?.inputTextField.text = ""
            }
        }
        
    }
    
    private func fetchMessages() {
        messagesDB.observe(.childAdded) { [weak self] snapshot in
            if let snapshotValue = snapshot.value as? [String: String] {
                guard let message = snapshotValue["message"] else { return }
                guard let sender = snapshotValue["sender"] else { return }
                self?.messages.append(MessageModel(message: message, sender: sender))
                self?.scrollToTheLastMessage()
            }
        }
    }
    
    @objc func tableViewWasTapped() {
        inputTextField.resignFirstResponder()
    }
    
    private func scrollToTheLastMessage() {
        if messages.count > 0 {
            let index = IndexPath(row: messages.count - 1, section: 0)
            messagesTableView.scrollToRow(at: index, at: .bottom, animated: true)
        }
    }
    
    @IBAction func logOut(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        } catch {
            print("could not log out, \(error)")
        }
    }
}

extension ChatViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        view.layoutIfNeeded()
        UIView.animate(withDuration: 0.2) {
            self.inputViewHeightConstraint.constant = self.inputViewHeightConstraint.constant + 300
            self.view.layoutIfNeeded()
        }
        scrollToTheLastMessage()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        view.layoutIfNeeded()
        UIView.animate(withDuration: 0.2) {
            self.inputViewHeightConstraint.constant = self.inputViewHeightConstraint.constant - 300
            self.view.layoutIfNeeded()
        }
        scrollToTheLastMessage()
    }
}

extension ChatViewController: UITableViewDelegate {
    
}

extension ChatViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: MessageCell.identifier, for: indexPath) as! MessageCell
        let message = messages[indexPath.row]
        cell.nameLabel.text = message.sender
        cell.messageLabel.text = message.message
        
        return cell
    }
    
    
}
