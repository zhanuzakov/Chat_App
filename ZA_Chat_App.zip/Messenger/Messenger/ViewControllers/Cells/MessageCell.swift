//
//  MessageCell.swift
//  Messenger
//
//  Created by Гость on 10.11.2021.
//

import UIKit

class MessageCell: UITableViewCell {
    
    public static let identifier = "MessageCell"

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        selectionStyle = .none
        
        avatarImageView.layer.cornerRadius = 20
        avatarImageView.layer.masksToBounds = true
        
        containerView.layer.cornerRadius = 8
        containerView.layer.masksToBounds = true
        
    }

}
