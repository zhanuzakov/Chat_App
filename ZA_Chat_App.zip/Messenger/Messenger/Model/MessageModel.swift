//
//  MessageModel.swift
//  Messenger
//
//  Created by Гость on 10.11.2021.
//

import Foundation

struct MessageModel {
    let message: String
    let sender: String
}
